package clases;

import java.awt.event.KeyEvent;

/**
 *
 * @author joare
 */
public class Funciones {


}
