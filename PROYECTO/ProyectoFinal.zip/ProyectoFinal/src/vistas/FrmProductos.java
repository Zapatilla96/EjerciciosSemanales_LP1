package vistas;

import clases.Controlador;
import java.awt.Color;
import java.awt.Point;
import java.awt.event.*;
import java.io.*;
import java.sql.ResultSet;
import java.util.*;
import java.util.logging.*;
import javax.swing.*;
import javax.swing.table.*;

/**
 *
 * @author Abigail Acosta y Liz Dominguez
 */
public class FrmProductos extends javax.swing.JFrame {

    /**
     * Creates new form FrmProductos
     */
    
    int xMouse, yMouse;
    ResultSet resultado;
    Controlador controlador;
    String objeto = "productos";
    String id = "id";
    String cadenaSQL = null;
    boolean editar = false;
    int estado = 0;
    int gencod = 0;
    
    
    File archivo = new File("data/inventario.csv");
    File archivoComboStock = new File("data/stock.csv");
    File archivoComboCategoria = new File("data/categoria.csv");
    File archivoComboProveedor = new File("data/proveedor.csv");
    String opcionBoton = null;
    int numeroEditar = 0;
    int numeroEliminar = 0;

    /**
     * Constructor
     */
    public FrmProductos() {
        initComponents();
        setTitle("Sistema de Inventario");
        setLocationRelativeTo(null);
        controlador = new Controlador();
        inicializar();
    }

    public void inicializar() {
        gencod = controlador.generarCodigo(objeto, id);
        txtCodigo.setText(String.valueOf(gencod));
        txtNombre.setText(null);
        txtDescripcion.setText(null);
        cboStock.setSelectedItem(null);
        cboCategoria.setSelectedItem(null);
        cboProveedor.setSelectedItem(null);
        tabListaProductos.setSelectedIndex(1);
        recuperarProductos();
    }

    private void verificarArchivo() {

        if (!archivo.exists()) {

            try {
                archivo.createNewFile();
                System.out.println("Archivo de base de datos creado correctamente");

                agregarCampo();

            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }

        } else {
            System.out.println("El archivo existe");
            try {
                leerArchivo();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        }
    }

    private void agregarCampo() {

        BufferedWriter escribirArchivo = null;
        try {
            try {
                escribirArchivo = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(archivo, true), "utf-8"));
            } catch (UnsupportedEncodingException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
            try {

                escribirArchivo.write("CÓDIGO" + "," + "NOMBRE" + "," + "DESCRIPCIÓN" + "," + "STOCK" + "," + "CATEGORÍA" + "," + "PROVEEDOR" + "\n");

            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
            System.out.println("Campos agregado correctamente");
            try {
                escribirArchivo.close();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } finally {
            try {
                escribirArchivo.close();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        }

    }

    private void leerArchivo() throws FileNotFoundException, IOException {

        String linea = null;
        int numeroRegistros = 0;
        BufferedReader leerFichero = new BufferedReader(new FileReader(archivo));

        while ((linea = leerFichero.readLine()) != null) {

            numeroRegistros += 1;

        }

        leerFichero.close();

        if (numeroRegistros == 0) {

            System.out.println("No existen registros en el archivo");

        } else {

            String delimitador = ",";
            leerFichero = new BufferedReader(new FileReader(archivo));
            String strLine = "";
            StringTokenizer st = null;
            int lineNumber = 0, tokenNumber = 0;
            String[][] datos = new String[numeroRegistros][10];
            int posicion = 0;

            while ((strLine = leerFichero.readLine()) != null) {

                lineNumber++;
                st = new StringTokenizer(strLine, delimitador);

                while (st.hasMoreTokens()) {

                    tokenNumber++;
                    datos[posicion][0] = st.nextToken().trim();
                    datos[posicion][1] = st.nextToken().trim();
                    datos[posicion][2] = st.nextToken().trim();
                    datos[posicion][3] = st.nextToken().trim();
                    datos[posicion][4] = st.nextToken().trim();
                    datos[posicion][5] = st.nextToken().trim();
                    posicion += 1;

                }
                tokenNumber = 0;
            }

            leerFichero.close();

            DefaultTableModel modelo = (DefaultTableModel) tblProductos.getModel();
            limpiarTabla(modelo);
            for (int i = 1; i < datos.length; i++) {
                String[] data = new String[11];
                data[0] = String.valueOf(i + 1);
                for (int j = 0; j < datos[i].length; j++) {
                    data[(j + 1)] = datos[i][j];
                }
                modelo.addRow(data);
            }

        }
    }

    private void cargarComboStock() {

        cboStock.removeAllItems();
        try {
            BufferedReader ficheroaleer = new BufferedReader(new FileReader(archivoComboStock));
            String linea;

            while ((linea = ficheroaleer.readLine()) != null) {

                StringTokenizer tokens = new StringTokenizer(linea, ",");
                String estado = (String) tokens.nextElement();

                cboStock.addItem(tokens.nextToken());

            }

            ficheroaleer.close();

        } catch (Exception x) {
            x.printStackTrace();
        }

    }

    private void cargarComboCategoria() {

        cboCategoria.removeAllItems();
        try {
            BufferedReader ficheroaleer = new BufferedReader(new FileReader(archivoComboCategoria));
            String linea;

            while ((linea = ficheroaleer.readLine()) != null) {

                StringTokenizer tokens = new StringTokenizer(linea, ",");
                String categoria = (String) tokens.nextElement();

                cboCategoria.addItem(tokens.nextToken());

            }

            ficheroaleer.close();

        } catch (Exception x) {
            x.printStackTrace();
        }

    }

    private void cargarComboProveedor() {

        cboProveedor.removeAllItems();
        try {
            BufferedReader ficheroaleer = new BufferedReader(new FileReader(archivoComboProveedor));
            String linea;

            while ((linea = ficheroaleer.readLine()) != null) {

                StringTokenizer tokens = new StringTokenizer(linea, ",");
                String proveedor = (String) tokens.nextElement();

                cboProveedor.addItem(tokens.nextToken());

            }

            ficheroaleer.close();

        } catch (Exception x) {
            x.printStackTrace();
        }
    }

    public void limpiarTabla(DefaultTableModel modelo) {
        for (int i = tblProductos.getRowCount() - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tabListaProductos = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnCancelar1 = new javax.swing.JButton();
        title = new javax.swing.JLabel();
        ID = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        cboStock = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        cboCategoria = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        cboProveedor = new javax.swing.JComboBox<>();
        txtNombre = new javax.swing.JTextField();
        jSeparator4 = new javax.swing.JSeparator();
        txtDescripcion = new javax.swing.JTextField();
        jSeparator5 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblProductos = new javax.swing.JTable();
        btnEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnExportar = new javax.swing.JButton();
        bgPanel = new javax.swing.JPanel();
        exitBtn = new javax.swing.JPanel();
        exitTxt = new javax.swing.JLabel();
        citybg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel2.setText("Nombre");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 80, -1, -1));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel4.setText("Descripción");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        jLabel7.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel7.setText("Stock");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, -1, -1));

        txtCodigo.setBackground(new java.awt.Color(153, 204, 255));
        txtCodigo.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        txtCodigo.setBorder(null);
        txtCodigo.setEnabled(false);
        txtCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoActionPerformed(evt);
            }
        });
        jPanel2.add(txtCodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, 150, 20));

        btnGuardar.setBackground(new java.awt.Color(0, 153, 0));
        btnGuardar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        jPanel2.add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 420, 150, 40));

        btnCancelar1.setBackground(new java.awt.Color(0, 153, 0));
        btnCancelar1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        btnCancelar1.setForeground(new java.awt.Color(255, 255, 255));
        btnCancelar1.setText("Cancelar");
        btnCancelar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelar1ActionPerformed(evt);
            }
        });
        jPanel2.add(btnCancelar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 420, 150, 40));

        title.setFont(new java.awt.Font("Roboto Black", 1, 24)); // NOI18N
        title.setText("PRODUCTOS");
        jPanel2.add(title, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 10, -1, -1));

        ID.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        ID.setText("Código");
        jPanel2.add(ID, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, 20));

        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 150, 20));

        cboStock.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        cboStock.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Disponible", "No disponible" }));
        cboStock.setEnabled(false);
        cboStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboStockActionPerformed(evt);
            }
        });
        jPanel2.add(cboStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, 260, -1));

        jLabel9.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel9.setText("Categoría");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 260, -1, -1));

        cboCategoria.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        cboCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Alimentos", "Papeleria", "Deportes", "Salud" }));
        cboCategoria.setEnabled(false);
        cboCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboCategoriaActionPerformed(evt);
            }
        });
        jPanel2.add(cboCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 260, 230, -1));

        jLabel10.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel10.setText("Proveedor");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, -1, -1));

        cboProveedor.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        cboProveedor.setEnabled(false);
        cboProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboProveedorActionPerformed(evt);
            }
        });
        jPanel2.add(cboProveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 360, 620, -1));

        txtNombre.setBackground(new java.awt.Color(153, 204, 255));
        txtNombre.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        txtNombre.setBorder(null);
        txtNombre.setEnabled(false);
        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        jPanel2.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 80, 380, 20));

        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 100, 380, 20));

        txtDescripcion.setBackground(new java.awt.Color(153, 204, 255));
        txtDescripcion.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        txtDescripcion.setBorder(null);
        txtDescripcion.setEnabled(false);
        txtDescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDescripcionActionPerformed(evt);
            }
        });
        jPanel2.add(txtDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 170, 610, 20));

        jSeparator5.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, 610, 20));

        tabListaProductos.addTab("Registro", jPanel2);

        jPanel3.setBackground(new java.awt.Color(153, 204, 255));

        tblProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(tblProductos);

        btnEditar.setBackground(new java.awt.Color(0, 153, 0));
        btnEditar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        btnEditar.setForeground(new java.awt.Color(255, 255, 255));
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(0, 153, 0));
        btnEliminar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnExportar.setBackground(new java.awt.Color(0, 153, 0));
        btnExportar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        btnExportar.setForeground(new java.awt.Color(255, 255, 255));
        btnExportar.setText("Exportar");
        btnExportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(121, 121, 121)
                .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(106, 106, 106)
                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnExportar, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 768, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExportar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22))
        );

        tabListaProductos.addTab("Lista", jPanel3);

        bgPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exitBtn.setBackground(new java.awt.Color(255, 255, 255));

        exitTxt.setFont(new java.awt.Font("Roboto Light", 0, 24)); // NOI18N
        exitTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitTxt.setText("X");
        exitTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        exitTxt.setPreferredSize(new java.awt.Dimension(40, 40));
        exitTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitTxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitTxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitTxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout exitBtnLayout = new javax.swing.GroupLayout(exitBtn);
        exitBtn.setLayout(exitBtnLayout);
        exitBtnLayout.setHorizontalGroup(
            exitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(exitTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        exitBtnLayout.setVerticalGroup(
            exitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(exitTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        bgPanel.add(exitBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        citybg.setBackground(new java.awt.Color(0, 134, 190));
        citybg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/pexels-jahoo-clouseau-388415.jpg"))); // NOI18N
        bgPanel.add(citybg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 540));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(bgPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tabListaProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 780, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tabListaProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bgPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboStockActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboStockActionPerformed

    private void cboProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboProveedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboProveedorActionPerformed

    public void recuperarProductos() {
        String cadenaSQL = "SELECT codigo,nombre,descripcion,stock,categoria,proveedor AS estado FROM clientes";
        controlador.cargarJTable((DefaultTableModel) tblProductos.getModel(), cadenaSQL);
    }
    
    
    public void almacenarFichero() {
        try {
            archivo.delete();
            archivo.createNewFile();
            agregarCampo();

            BufferedWriter escribirArchivo = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(archivo, true), "utf-8"));
            for (int i = 0; i < tblProductos.getRowCount(); i++) {
                escribirArchivo.write(tblProductos.getValueAt(i, 1) + "," + tblProductos.getValueAt(i, 2) + "," + tblProductos.getValueAt(i, 3) + "," + tblProductos.getValueAt(i, 4) + "," + tblProductos.getValueAt(i, 5) + "," + tblProductos.getValueAt(i, 6) + "," + tblProductos.getValueAt(i, 7) + "\n");
            }
            escribirArchivo.close();
            leerArchivo();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    public void edicion() {
        for (int i = 0; i < tblProductos.getRowCount(); i++) {
            if (numeroEditar == Integer.parseInt((String) tblProductos.getValueAt(i, 0))) {
                tblProductos.setValueAt(numeroEditar, i, 0);
                tblProductos.setValueAt(txtCodigo.getText(), i, 1);
                tblProductos.setValueAt(txtNombre.getText(), i, 2);
                tblProductos.setValueAt(txtDescripcion.getText(), i, 3);
                tblProductos.setValueAt(cboStock.getSelectedItem(), i, 4);
                tblProductos.setValueAt(cboCategoria.getSelectedItem(), i, 5);
                tblProductos.setValueAt(cboProveedor.getSelectedItem(), i, 6);
                break;
            }
        }
    }


    private void cboCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboCategoriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboCategoriaActionPerformed

    private void txtCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        String codigo = txtCodigo.getText();
        String nombre = txtNombre.getText();
        String descripcion = txtDescripcion.getText();
        String stock = (String) cboStock.getSelectedItem();
        String categoria = (String) cboCategoria.getSelectedItem();
        String proveedor = (String) cboProveedor.getSelectedItem();

        if (nombre.isEmpty() || descripcion.isEmpty() || stock.isEmpty() || categoria.isEmpty() || proveedor.isEmpty()) {
            String mensaje = "¡Complete todos los campos!";
            JOptionPane.showMessageDialog(this, mensaje);
            return;
        }

        if (!editar) {
            cadenaSQL = "INSERT INTO clientes VALUES (";
            cadenaSQL += id;
            cadenaSQL += ",'";
            cadenaSQL += nombre;
            cadenaSQL += "','";
            cadenaSQL += descripcion;
            cadenaSQL += "','";
            cadenaSQL += stock;
            cadenaSQL += "','";
            cadenaSQL += categoria;
            cadenaSQL += "','";
            cadenaSQL += proveedor;
            cadenaSQL += ")";
        } else {
            cadenaSQL = "UPDATE clientes SET ";
            cadenaSQL += "codigo='" + codigo;
            cadenaSQL += "',";
            cadenaSQL += "nombre='" + nombre;
            cadenaSQL += "',";
            cadenaSQL += "descripcion='" + descripcion;
            cadenaSQL += "',";
            cadenaSQL += "stock='" + stock;
            cadenaSQL += "',";
            cadenaSQL += "categoria='" + categoria;
            cadenaSQL += "',";
            cadenaSQL += "proveedor='" + proveedor;
            cadenaSQL += " WHERE id=" + id;
        }
        boolean operacion = controlador.actualizar(cadenaSQL);
        System.err.println("Operacion: " + operacion);
        inicializar();
        tabListaProductos.setSelectedIndex(1);
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnCancelar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelar1ActionPerformed
        inicializar();
        tabListaProductos.setSelectedIndex(1);
    }//GEN-LAST:event_btnCancelar1ActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        int fila = tblProductos.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "¡Seleccione un registro!", "AVISO", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String id = tblProductos.getValueAt(tblProductos.getSelectedRow(), 0).toString();
        try {
            cadenaSQL = "SELECT * FROM productos WHERE id = " + id;
            resultado = controlador.consultar(cadenaSQL);
            if (resultado.next()) {
                txtCodigo.setText(resultado.getString(1));
                txtNombre.setText(resultado.getString(2));
                txtDescripcion.setText(resultado.getString(3));
                cboStock.setSelectedItem(resultado.getString(4));
                cboCategoria.setSelectedItem(resultado.getString(5));
                cboProveedor.setSelectedItem(resultado.getString(6));
                tabListaProductos.setSelectedIndex(0);
                txtNombre.grabFocus();
                editar = true;
            }
        } catch (SQLException ex) {
            System.err.println("ERROR ACTUALIZANDO: " + ex);
        }
        controlador.desconectar();
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = tblProductos.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "¡Seleccione un registro!", "AVISO", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int pregunta = JOptionPane.showConfirmDialog(this, "¿Borrar Registro?", "ATENCION", JOptionPane.YES_NO_OPTION);
        if (pregunta == JOptionPane.NO_OPTION) {
            return;
        }
        String id = tblProductos.getValueAt(tblProductos.getSelectedRow(), 0).toString();
        String cadenaSQL = "DELETE FROM clientes WHERE id = " + id;
        boolean operacion = controlador.actualizar(cadenaSQL);
        System.err.println("Operacion: " + operacion);
        inicializar();
        tabListaProductos.setSelectedIndex(1);
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnExportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportarActionPerformed
        HashMap parametro = new HashMap();
        parametro.put("param1", "");
        Connection con = op.getConexion();
        URL urlReporte = getClass().getClassLoader().getResource("reportes/rptPersonas.jasper");
        System.out.println(urlReporte.getPath());
        try {
            JasperReport maestroReporte = (JasperReport) JRLoader.loadObject(urlReporte);
            JasperPrint maestroPrint = JasperFillManager.fillReport(maestroReporte, parametro, con);
            JasperViewer verReporte = new JasperViewer(maestroPrint, false);
            verReporte.setTitle("Vista previa - Listado de personas");
            verReporte.setVisible(true);
        } catch (JRException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnExportarActionPerformed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtDescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDescripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDescripcionActionPerformed

    private void exitTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitTxtMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitTxtMouseClicked

    private void exitTxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitTxtMouseEntered
        exitBtn.setBackground(Color.red);
        exitTxt.setForeground(Color.white);
    }//GEN-LAST:event_exitTxtMouseEntered

    private void exitTxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitTxtMouseExited
        exitBtn.setBackground(Color.white);
        exitTxt.setForeground(Color.black);
    }//GEN-LAST:event_exitTxtMouseExited

    public final void asignarEventoMouse() {
        tblProductos.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent Mouse_event) {
                JTable tabla = (JTable) Mouse_event.getSource();
                Point point = Mouse_event.getPoint();
                int row = tabla.rowAtPoint(point);
                if (Mouse_event.getClickCount() == 2) {
                    btnEditar.setEnabled(true);
                    btnEliminar.setEnabled(true);
                    btnExportar.setEnabled(true);

                    numeroEditar = Integer.parseInt("" + tabla.getValueAt(tabla.getSelectedRow(), 0));
                    numeroEliminar = numeroEditar;
                    txtCodigo.setText("" + tabla.getValueAt(tabla.getSelectedRow(), 1));
                    txtNombre.setText("" + tabla.getValueAt(tabla.getSelectedRow(), 2));
                    txtDescripcion.setText("" + tabla.getValueAt(tabla.getSelectedRow(), 3));
                    cboStock.setSelectedItem("" + tabla.getValueAt(tabla.getSelectedRow(), 4));
                    cboCategoria.setSelectedItem("" + tabla.getValueAt(tabla.getSelectedRow(), 5));
                    cboProveedor.setSelectedItem("" + tabla.getValueAt(tabla.getSelectedRow(), 6));
                }
            }
        });
    }

    public void habilitarCajasTextos(boolean estado) {
        txtCodigo.setEnabled(estado);
        txtNombre.setEnabled(estado);
        txtDescripcion.setEnabled(estado);
        cboStock.setEnabled(estado);
        cboCategoria.setEnabled(estado);
        cboProveedor.setEnabled(estado);
    }

    public void IniciarCajasTextos() {
        txtCodigo.setText(null);
        txtNombre.setText(null);
        txtDescripcion.setText(null);
        cargarComboStock();
        cargarComboCategoria();
        cargarComboProveedor();

    }

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {
        habilitarCajasTextos(true);
        IniciarCajasTextos();
        btnEditar.setEnabled(false);
        btnGuardar.setEnabled(true);
        btnEditar.setEnabled(false);
        btnExportar.setEnabled(true);
        opcionBoton = "Nuevo";
    }

    private void ingresarProductos() {
        BufferedWriter escribirArchivo = null;
        try {
            try {
                escribirArchivo = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(archivo, true), "utf-8"));
            } catch (UnsupportedEncodingException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
            try {
                System.out.println("clases.GestionarProductos.ingresarProductos(): " + cboStock.getSelectedItem() + cboCategoria.getSelectedItem() + cboProveedor.getSelectedItem() );
                escribirArchivo.write(txtCodigo.getText() + "," + txtNombre.getText() + "," + txtDescripcion.getText() + "," + cboStock.getSelectedItem() + "," + cboCategoria.getSelectedItem() + "," + cboProveedor.getSelectedItem() + "\n");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
            JOptionPane.showMessageDialog(null, "Producto ingresado correctamente");
            try {
                escribirArchivo.close();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
            try {
                leerArchivo();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } finally {
            try {
                escribirArchivo.close();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
  

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ID;
    private javax.swing.JPanel bgPanel;
    private javax.swing.JButton btnCancelar1;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnExportar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JComboBox<String> cboCategoria;
    private javax.swing.JComboBox<String> cboProveedor;
    private javax.swing.JComboBox<String> cboStock;
    private javax.swing.JLabel citybg;
    private javax.swing.JPanel exitBtn;
    private javax.swing.JLabel exitTxt;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JTabbedPane tabListaProductos;
    private javax.swing.JTable tblProductos;
    private javax.swing.JLabel title;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
