-- ---
-- Globals
-- ---

-- SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
-- SET FOREIGN_KEY_CHECKS=0;

-- ---
-- Table 'egresos'
-- 
-- ---

DROP TABLE IF EXISTS `egresos`;
		
CREATE TABLE `egresos` (
  `id` INTEGER NOT NULL AUTO_INCREMENT,
  `compras` INTEGER NOT NULL,
  `id_inventario` INTEGER NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
);

-- ---
-- Table 'ingresos'
-- 
-- ---

DROP TABLE IF EXISTS `ingresos`;
		
CREATE TABLE `ingresos` (
  `id` INTEGER NOT NULL AUTO_INCREMENT,
  `ventas` MEDIUMTEXT NOT NULL,
  `id_inventario` INTEGER NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
);

-- ---
-- Table 'inventario'
-- 
-- ---

DROP TABLE IF EXISTS `inventario`;
		
CREATE TABLE `inventario` (
  `id` INTEGER NULL AUTO_INCREMENT DEFAULT NULL,
  `articulos` INTEGER NOT NULL,
  `id_producto` INTEGER NOT NULL,
  PRIMARY KEY (`id`)
);

-- ---
-- Table 'producto'
-- 
-- ---

DROP TABLE IF EXISTS `producto`;
		
CREATE TABLE `producto` (
  `id` INTEGER NOT NULL AUTO_INCREMENT,
  `codigo` INTEGER NOT NULL,
  `imagen` VARCHAR NOT NULL,
  `nombre` MEDIUMTEXT NOT NULL,
  `descripcion` MEDIUMTEXT NOT NULL,
  `precio` INTEGER NOT NULL,
  `estado` INTEGER NOT NULL,
  `id_categoria` INTEGER NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
);

-- ---
-- Table 'stock'
-- 
-- ---

DROP TABLE IF EXISTS `stock`;
		
CREATE TABLE `stock` (
  `id` INTEGER NULL AUTO_INCREMENT DEFAULT NULL,
  `disponibilidad` INTEGER NOT NULL,
  `id_producto` INTEGER NOT NULL,
  PRIMARY KEY (`id`)
);

-- ---
-- Table 'categoria'
-- 
-- ---

DROP TABLE IF EXISTS `categoria`;
		
CREATE TABLE `categoria` (
  `id` INTEGER NULL AUTO_INCREMENT DEFAULT NULL,
  `alimento` MEDIUMTEXT NOT NULL,
  `papeleria` MEDIUMTEXT NOT NULL,
  `deportes` MEDIUMTEXT NOT NULL,
  `salud` MEDIUMTEXT NOT NULL,
  PRIMARY KEY (`id`)
);

-- ---
-- Foreign Keys 
-- ---

ALTER TABLE `egresos` ADD FOREIGN KEY (id_inventario) REFERENCES `inventario` (`id`);
ALTER TABLE `ingresos` ADD FOREIGN KEY (id_inventario) REFERENCES `inventario` (`id`);
ALTER TABLE `inventario` ADD FOREIGN KEY (id_producto) REFERENCES `producto` (`id`);
ALTER TABLE `producto` ADD FOREIGN KEY (id_categoria) REFERENCES `categoria` (`id`);
ALTER TABLE `stock` ADD FOREIGN KEY (id_producto) REFERENCES `producto` (`id`);

-- ---
-- Table Properties
-- ---

-- ALTER TABLE `egresos` ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE `ingresos` ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE `inventario` ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE `producto` ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE `stock` ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE `categoria` ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ---
-- Test Data
-- ---

-- INSERT INTO `egresos` (`id`,`compras`,`id_inventario`) VALUES
-- ('','','');
-- INSERT INTO `ingresos` (`id`,`ventas`,`id_inventario`) VALUES
-- ('','','');
-- INSERT INTO `inventario` (`id`,`articulos`,`id_producto`) VALUES
-- ('','','');
-- INSERT INTO `producto` (`id`,`codigo`,`imagen`,`nombre`,`descripcion`,`precio`,`estado`,`id_categoria`) VALUES
-- ('','','','','','','','');
-- INSERT INTO `stock` (`id`,`disponibilidad`,`id_producto`) VALUES
-- ('','','');
-- INSERT INTO `categoria` (`id`,`alimento`,`papeleria`,`deportes`,`salud`) VALUES
-- ('','','','','');