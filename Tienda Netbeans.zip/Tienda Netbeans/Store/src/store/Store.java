package store;

public class Store {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Login ventana1 = new Login();        
    }
    
}
