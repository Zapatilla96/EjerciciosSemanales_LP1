/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author Jorge Arevalos
 */
public class formSplash extends JWindow {

    public formSplash() {
        JWindow jwindow = new JWindow();

        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();

        Icon img= new ImageIcon(this.getClass().getResource("/images/splash.jpg"));

        JLabel label = new JLabel(img);
        label.setSize(200, 300);
        jwindow.getContentPane().add(label);
        jwindow.setBounds(((int) dimension.getWidth() - 722) / 2, ((int) dimension.getHeight() - 401) / 2, 722, 401);
        jwindow.setVisible(true);
        
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        jwindow.setVisible(false);

    }

    public static void main(String[] args) {
        formSplash s = new formSplash();
    }
    
}
