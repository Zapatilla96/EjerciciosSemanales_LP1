/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author joarevalos
 */
public class sentencias extends conexion {

    ResultSet rs = null;

    //constructor
    public sentencias() {
    }

    public boolean actualizar(String cSQL) {
        boolean valor = true;
        conectar();
        System.out.println(cSQL);
        try {
            consulta.executeUpdate(cSQL);
        } catch (SQLException ex) {
            Logger.getLogger(sentencias.class.getName()).log(Level.SEVERE, null, ex);
            valor = false;
        }
        desconectar();
        return valor;
    }

    public ResultSet consultar(String cSQL) {
        ResultSet resultado = null;
        conectar();
        System.out.println(cSQL);
        try {
            resultado = consulta.executeQuery(cSQL);
        } catch (SQLException ex) {
            Logger.getLogger(sentencias.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }

    public int generarCodigo(String tabla, String id) {
        int codigo = 1;
        ResultSet resultado = null;
        String cSQL = "SELECT MAX(" + id + ") as ultimo from " + tabla;
        try {
            resultado = consultar(cSQL);
            if (resultado.next()) {
                codigo = resultado.getInt("ultimo") + 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(sentencias.class.getName()).log(Level.SEVERE, null, ex);
        }
        desconectar();
        return codigo;
    }

    public void cargarJTabla(DefaultTableModel jtablemodelo, String cSQL) {
        ResultSet resultado = null;
        jtablemodelo.setRowCount(0);
        jtablemodelo.setColumnCount(0);
        try {
            resultado = consultar(cSQL);
            if (resultado != null) {
                int nCol = resultado.getMetaData().getColumnCount();
                for (int m = 1; m <= nCol; m++) {
                    jtablemodelo.addColumn(resultado.getMetaData().getColumnName(m).toUpperCase());
                }
                while (resultado.next()) {
                    Object[] filas = new Object[nCol];
                    for (int j = 1; j <= nCol; j++) {
                        filas[j - 1] = resultado.getObject(j);
                    }
                    jtablemodelo.addRow(filas);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(sentencias.class.getName()).log(Level.SEVERE, null, ex);
        }
        desconectar();
    }

    public void cargarJCombo(JComboBox combo, String cSQL) {
        ResultSet resultado = null;
        DefaultComboBoxModel modelocombo = new DefaultComboBoxModel();
        resultado = consultar(cSQL);
        try {
            while (resultado.next()) {
                combobox cbo = new combobox();
                cbo.setCodigo(resultado.getString(1));
                cbo.setDato(resultado.getString(2));
                modelocombo.addElement(cbo);
            }
            combo.setModel(modelocombo);
        } catch (SQLException ex) {
            Logger.getLogger(sentencias.class.getName()).log(Level.SEVERE, null, ex);
        }
        desconectar();
    }

    public void desconectar() {
        try {
            System.out.println("Desconexion de SQlite, finalizado!");
            consulta.close();
            conex.close();
        } catch (SQLException ex) {
            Logger.getLogger(sentencias.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
