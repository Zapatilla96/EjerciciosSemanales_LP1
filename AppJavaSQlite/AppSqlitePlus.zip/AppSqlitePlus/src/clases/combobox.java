/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author joarevalos
 */
public class combobox {

    private String codigo;
    private String dato;

    //contructor pro defecto
    public combobox() {
        super();
    }

    //constructor
    public combobox(String codigo, String dato) {
        this.codigo = codigo;
        this.dato = dato;
    }

    //setter
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setDato(String dato) {
        this.dato = dato;
    }

    //getter
    public String getCodigo() {
        return this.codigo;
    }

    public String getDato() {
        return this.dato;
    }

    public String toString() {
        return dato;
    }
}
