/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author joarevalos
 */
public class conexion {

    protected Connection conex;
    protected Statement consulta;
    private String rutadata;

    //constructor
    public conexion() {
        File fichero = new File("data/personas.db");
        rutadata = fichero.getAbsolutePath();
        System.err.println(rutadata);
    }

    public void conectar() {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException ex) {
            System.err.println("Hubo un error grave, no existe la clase");
        }
        try {
            conex = DriverManager.getConnection("jdbc:sqlite:" + rutadata);
        } catch (SQLException ex) {
            System.err.println("No se pudo conectar a la base de datos!");
        }
        try {
            consulta = conex.createStatement();
            System.out.println("Conexion a SQlite, correcto!");
        } catch (SQLException ex) {
            System.err.println("No se puede ejecutar consulta sobre la base de datos!");
        }
    }

    public Connection getConexion() {
        Connection con = null;
        try {
            conectar();
            con = consulta.getConnection();
        } catch (SQLException ex) {
            Logger.getLogger(conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
}
