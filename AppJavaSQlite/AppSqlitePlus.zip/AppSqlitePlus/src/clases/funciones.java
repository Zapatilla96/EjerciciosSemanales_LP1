/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import com.toedter.calendar.JDateChooser;
import java.awt.event.KeyEvent;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author joarevalos
 */
public class funciones {

    public void mayuscula(KeyEvent x) {
        char c = x.getKeyChar();
        String cc = (String.valueOf(c)).toUpperCase();
        c = cc.charAt(0);
        x.setKeyChar(c);
    }

    public String vectoracadenaedita(String[] campos, Object[] vectordatos) {
        String cadena = "";

        for (int x = 0; x < campos.length; x++) {
            cadena = cadena + campos[x] + " = '" + vectordatos[x + 1] + "', ";
        }

        return cadena.substring(0, cadena.length() - 2);
    }

    public String vectoracadena(Object[] vectordatos) {
        String cadena = "'";
        for (int x = 0; x < vectordatos.length; x++) {
            cadena = cadena + vectordatos[x];

            if (x + 1 < vectordatos.length) {
                cadena = cadena + "','";
            } else {
                cadena = cadena + "'";
            }
        }
        return cadena;
    }

    public String fechaacadena(JDateChooser tmp) {
        return String.valueOf(tmp.getDate().getDate())
                + "/" + String.valueOf(tmp.getDate().getMonth() + 1)
                + "/" + String.valueOf(tmp.getDate().getYear() + 1900);
    }

    public void bloqueaobjetos(JPanel panel, boolean modo) {
        for (int x = 0; x < panel.getComponentCount(); x++) {
            if (panel.getComponent(x).getClass().equals(JTextField.class)
                    || panel.getComponent(x).getClass().equals(JDateChooser.class)
                    || panel.getComponent(x).getClass().equals(JComboBox.class)
                    || panel.getComponent(x).getClass().equals(JButton.class)) {

                panel.getComponent(x).setEnabled(modo);
            }
        }
    }

}
